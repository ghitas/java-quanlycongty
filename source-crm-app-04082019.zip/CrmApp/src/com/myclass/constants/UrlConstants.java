package com.myclass.constants;

public class UrlConstants {
	public final static String ROLE_LIST = "/admin/role";
	public final static String ROLE_ADD = "/admin/role/add";
	public final static String ROLE_EDIT = "/admin/role/edit";
	public final static String ROLE_DELETE = "/admin/role/delete";
}
