package com.myclass.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myclass.dto.UserDto;

public class AuthFilter implements Filter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse resp = (HttpServletResponse)response;
		
		String action = req.getServletPath();
		
		// Kiểm tra nếu url == /login thì không yêu cầu đăng nhập
		if(action.equals("/login") || action.startsWith("/error")) {
			chain.doFilter(request, response);
			return;
		}
		
		// Kiểm tra đăng nhập
		HttpSession session = req.getSession();
		if (session.getAttribute("USER_LOGIN") == null) { // CHưa đăng nhập
			// Chuyển hướng về trang login để đăng nhập
			resp.sendRedirect(req.getContextPath() + "/login?error=123");
			return;
		}
		
		// ========--------- PHÂN QUYỀN ---------============
		
		System.out.println(action);
		System.out.println(action.startsWith("/manager"));
		
		// Kiểm tra url bắt đầu bằng /admin
		if(action.startsWith("/admin")) {
			UserDto user = (UserDto)session.getAttribute("USER_LOGIN");
			// Kiểm tra quyền của người dùng
			if(user.getRoleName().equals("ROLE_ADMIN")) {
				// Nếu có quyền ADMIN => cho phép đi vào Servlet đích
				chain.doFilter(request, response);
			}
			else {
				resp.sendRedirect(req.getContextPath() + "/error/403");
			}
		}
		
		else if(action.startsWith("/manager")) {
			UserDto user = (UserDto)session.getAttribute("USER_LOGIN");
			// Kiểm tra quyền của người dùng
			if(user.getRoleName().equals("ROLE_MANAGER") || user.getRoleName().equals("ROLE_ADMIN")) {
				// Nếu có quyền ADMIN hoặc MANAGER => cho phép đi vào Servlet đích
				chain.doFilter(request, response);
			}
			else {
				resp.sendRedirect(req.getContextPath() + "/error/403");
			}
		}
		else {
			chain.doFilter(request, response);
		}
		

	}

}
