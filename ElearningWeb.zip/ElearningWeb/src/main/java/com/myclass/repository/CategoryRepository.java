package com.myclass.repository;

import com.myclass.entity.Category;

public interface CategoryRepository extends CrudRepository<Category, Integer> {

}
