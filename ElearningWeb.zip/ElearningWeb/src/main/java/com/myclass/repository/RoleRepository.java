package com.myclass.repository;

import com.myclass.entity.Role;

public interface RoleRepository extends CrudRepository<Role, String> {
	
}
