package com.myclass.entity;

public class Account {
	private int id;
	private String ownerName;
	private long balance;
	
	public Account() {}

	public Account(int id, String ownerName, long balance) {
		super();
		this.id = id;
		this.ownerName = ownerName;
		this.balance = balance;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}
}
