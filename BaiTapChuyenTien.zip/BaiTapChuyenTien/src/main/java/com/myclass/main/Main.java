package com.myclass.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContextExtensionsKt;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.myclass.config.AppConfig;
import com.myclass.entity.Account;
import com.myclass.service.AccountService;

public class Main {

	public static void main(String[] args) {
		
		//ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		AccountService accountService = (AccountService)context.getBean("accountServiceImpl");
		
		// Thêm cho list 2 tài khoản
		Account account1 = new Account(1, "Nguyễn Văn A", 20000000);
		Account account2 = new Account(2, "Nguyễn Văn B", 10000000);
		accountService.insert(account1);
		accountService.insert(account2);
		
		// In ra thông tin hai tài khoản trước chuyển tiền
		
		System.out.println("----=== TÀI KHOẢN TRƯỚC KHI CHUYỂN ====-----");
		System.out.println("Tài khoản chuyển:");
		Account acc1 = accountService.findById(1);
		System.out.println("Họ tên: " + acc1.getOwnerName());
		System.out.println("Số dư: " + acc1.getBalance());
		
		System.out.println("Tài khoản nhận:");
		Account acc2 = accountService.findById(2);
		System.out.println("Họ tên: " + acc2.getOwnerName());
		System.out.println("Số dư: " + acc2.getBalance());
		
		// Thực hiện chuyển tiền
		accountService.transferMoney(1, 2, 5000000);
		
		// In ra thông tin hai tài khoản sau chuyển tiền
		System.out.println("----=== TÀI KHOẢN SAU KHI CHUYỂN ====-----");
		System.out.println("Tài khoản chuyển:");
		acc1 = accountService.findById(1);
		System.out.println("Họ tên: " + acc1.getOwnerName());
		System.out.println("Số dư: " + acc1.getBalance());
		
		System.out.println("Tài khoản nhận:");
		acc2 = accountService.findById(2);
		System.out.println("Họ tên: " + acc2.getOwnerName());
		System.out.println("Số dư: " + acc2.getBalance());
	}
}
