package com.myclass.service;

import com.myclass.entity.Account;

public interface AccountService {
	void insert(Account account);
	void transferMoney(int fromId,int toId,long mount);
	Account findById(int id);
}
