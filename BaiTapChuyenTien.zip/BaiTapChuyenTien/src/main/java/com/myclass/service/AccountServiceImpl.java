package com.myclass.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myclass.entity.Account;
import com.myclass.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	private AccountRepository accountRepository;
	
//	public AccountServiceImpl(AccountRepository accountRepository) {
//		this.accountRepository = accountRepository;
//	}

	public void insert(Account account) {
		accountRepository.add(account);
	}

	public void transferMoney(int fromId, int toId,long mount) {
		// Lấy ra thông tin người chuyển & người nhận
		Account source = accountRepository.findById(fromId);
		Account target = accountRepository.findById(toId);
		
		// Thục hiện chuyển tiền + cập nhật
		source.setBalance(source.getBalance() - mount); // Trừ số dư tài khoản
		target.setBalance(target.getBalance() + mount); // Cộng số dư tài khoản
	}

	public Account findById(int id) {
		return accountRepository.findById(id);
	}

}
