package com.myclass.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.myclass")
public class AppConfig {

//	@Bean
//	public AccountRepository accountRepository() {
//		return new AccountRepositoryImpl();
//	}
	
//	<bean id="accountRepository" class="com.myclass.repository.AccountRepositoryImpl"></bean>
	
	
//	@Bean 
//	public AccountService accountService() {
//		return new AccountServiceImpl(accountRepository());
//	}
	
	/**
	 * <bean id="accountService" class="com.myclass.service.AccountServiceImpl">
			<constructor-arg ref="accountRepository" />
		</bean>
	 */
}
