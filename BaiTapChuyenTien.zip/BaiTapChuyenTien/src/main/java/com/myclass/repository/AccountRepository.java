package com.myclass.repository;

import com.myclass.entity.Account;

public interface AccountRepository {
	void add(Account account);
	void update(Account account);
	Account findById(int id);
}
