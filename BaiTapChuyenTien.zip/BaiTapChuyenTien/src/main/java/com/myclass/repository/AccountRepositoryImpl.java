package com.myclass.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.myclass.entity.Account;

@Repository
public class AccountRepositoryImpl implements AccountRepository{
	
	private List<Account> accounts;
	
	public AccountRepositoryImpl() {
		accounts = new ArrayList<Account>();
	}

	public void add(Account account) {
		accounts.add(account);
	}

	public void update(Account account) {
		Account model = findById(account.getId());
		model.setOwnerName(account.getOwnerName());
		model.setBalance(account.getBalance());
	}

	public Account findById(int id) {
		for(Account item: accounts) {
			if(item.getId() == id) {
				return item;
			}
		}
		return null;
	}

}
