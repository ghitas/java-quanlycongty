package pgkNhanSu;

import java.util.ArrayList;
import java.util.Scanner;

import pgkQuanLy.CongTy;

public class NhanVien extends NhanSu {
	private int _ma_truong_phong_quan_ly;

	public NhanVien() {
		this._he_so_luong = 1.0f;
		this._luong_1_ngay = 100;
		this._ma_truong_phong_quan_ly = -1;
	}
	
	public int getMaTruongPhongQuanLy() {
		return this._ma_truong_phong_quan_ly;
	}
	
	public void setMaTruongPhongQuanLy( int ma_truong_phong_moi ) {
		this._ma_truong_phong_quan_ly = ma_truong_phong_moi;
	}

	public void NhapDuLieu( CongTy cty ) {
		super.NhapDuLieu();

		int ma_tp_quan_ly = -1;
		while( true ) {
			System.out.println( "Mời bạn nhập mã trưởng phòng quản lý: ");
			ma_tp_quan_ly = Integer.parseInt(scan.nextLine());
			
			if( ma_tp_quan_ly == -1 ) // trường hợp ko muốn nv bị quản lý
				break;
			
			TruongPhong tp = cty.KiemTraTruongPhongTonTai(ma_tp_quan_ly);
			
			if( tp != null ) {
				System.out.println( "Đã liên kết nhân viên với trưởng phòng " + tp.getHoTen() );
				tp.ThemMotNhanVienDuoiQuyen(this);
				break;
			}
			else {				
				System.out.println( "Mã trưởng phòng không tồn tại, nhập lại!");
			}
		}
		
		this._ma_truong_phong_quan_ly = ma_tp_quan_ly;
	}
	
	@Override 
	public void XuatDuLieu() {
		super.XuatDuLieu();
		System.out.println( "Mã trưởng phòng quản lý: " + this._ma_truong_phong_quan_ly);
	}
}
