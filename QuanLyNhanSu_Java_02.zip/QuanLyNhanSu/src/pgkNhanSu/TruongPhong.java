package pgkNhanSu;

import java.util.ArrayList;
import java.util.Scanner;

public class TruongPhong extends NhanSu {
	protected int _so_luong_nhan_vien_duoi_quyen;
	protected ArrayList<NhanVien> _list_nhan_vien_duoi_quyen;
	
	protected final int _he_so_luong_quan_ly = 100;
	
	
	public TruongPhong() {
		this._he_so_luong = 1.5f;
		this._luong_1_ngay = 200;
		this._so_luong_nhan_vien_duoi_quyen = 0;
		this._list_nhan_vien_duoi_quyen = new ArrayList<NhanVien>();
	}
	
	@Override
	public void NhapDuLieu() {
		super.NhapDuLieu();
	} 
	
	@Override
	public void TinhLuong() {
		 super.TinhLuong();
		 this._luong_thang += this._he_so_luong_quan_ly * this._so_luong_nhan_vien_duoi_quyen;
	}
	
	public void ThemMotNhanVienDuoiQuyen( NhanVien nv ) {
		this._list_nhan_vien_duoi_quyen.add(nv);
		this._so_luong_nhan_vien_duoi_quyen++;
	}
	
	public void XoaLienKetKhoiCacNhanVien() {
		//Duyệt danh sách nhân viên dưới quyền
		//Set thuộc tính Mã TP Quản lý của từng nhân viên thành -1
		for( NhanVien nv : this._list_nhan_vien_duoi_quyen ) {
			System.out.println( "Đã ngắt kết nối đến nhân viên " + nv.getHoTen() );
			nv.setMaTruongPhongQuanLy(-1);
		}
		
		this._list_nhan_vien_duoi_quyen.clear();
		this._so_luong_nhan_vien_duoi_quyen = 0;
	}
}
