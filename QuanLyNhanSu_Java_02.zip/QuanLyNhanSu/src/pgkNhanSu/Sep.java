package pgkNhanSu;

import java.util.Scanner;

public class Sep extends NhanSu {
	private float _co_phan;
	public Sep() {
		this._he_so_luong = 2.0f;
		this._luong_1_ngay = 300;
		this._co_phan = 0;
	}
	
	public float getCoPhan() {
		return this._co_phan;
	}
	
	@Override
	public void NhapDuLieu() {
		super.NhapDuLieu();

		System.out.println( "Nhập vào số % cổ phẩn: ");
		this._co_phan = Float.parseFloat(scan.nextLine());
	}
	
	public float TinhThuNhapThang( float loi_nhuan_cong_ty ) {
		float co_tuc = this._co_phan * loi_nhuan_cong_ty / 100.0f;
		float tong_thu_nhap = this._luong_thang + co_tuc;
		return tong_thu_nhap;
	}
}
