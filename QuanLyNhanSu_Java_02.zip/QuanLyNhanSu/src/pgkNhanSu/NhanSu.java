package pgkNhanSu;

import java.util.Scanner;

import pgkInterface.INhapXuatDuLieu;

public abstract class NhanSu implements INhapXuatDuLieu {
	 protected static int _s_ma_so = 0;
	
	 protected int _ma_so;
	 protected String _ho_ten;
	 protected String _sdt;
	 protected int _so_ngay_lam_viec;
	 protected float _he_so_luong;
	 protected float _luong_1_ngay;
	 
	 protected float _luong_thang;
	 
	 public NhanSu() {
		 NhanSu._s_ma_so++;
		 this._ma_so = NhanSu._s_ma_so;
	 }
	 
	 public int getMaSo() {
		 return this._ma_so;
	 }
	 
	 public String getHoTen() {
		 return this._ho_ten;
	 }
	 
	 public float getLuongThang() {
		 return this._luong_thang;
	 }
	 
	 public void NhapDuLieu() {
		 System.out.println("Nhập họ tên:");
		 this._ho_ten = scan.nextLine();
		 
		 System.out.println( "Nhập số ngày làm viêc: ");
		 this._so_ngay_lam_viec = Integer.parseInt(scan.nextLine());
	 } 
	 
	 public void XuatDuLieu() {
		 System.out.println( "Mã số nv: " + this._ma_so );
		 System.out.println( "Họ tên: " + this._ho_ten );
		 System.out.println( "Số ngày làm việc: " + this._so_ngay_lam_viec );
		 System.out.println( "Lương tháng này: " + this._luong_thang );
	 }
	 
	 public void TinhLuong() {
		 this._luong_thang = this._he_so_luong * this._so_ngay_lam_viec * this._luong_1_ngay;
	 }

}
