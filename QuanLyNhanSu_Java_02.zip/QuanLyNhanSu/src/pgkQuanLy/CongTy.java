package pgkQuanLy;

import java.util.ArrayList;
import java.util.Scanner;

import pgkInterface.INhapXuatDuLieu;
import pgkNhanSu.NhanSu;
import pgkNhanSu.NhanVien;
import pgkNhanSu.Sep;
import pgkNhanSu.TruongPhong;

public class CongTy implements INhapXuatDuLieu {
	private ArrayList<NhanSu> _list_ns;
	private String _ten_cong_ty;
	private String _ma_so_thue;
	private float  _doanh_thu_thang;
	private float _luong_thang_cua_cong_ty;
	
	public CongTy() {
		this._list_ns = new ArrayList<NhanSu>();
		this._ten_cong_ty = "";
		this._ma_so_thue = "";
		this._doanh_thu_thang = 0;
	}
	
	public void NhapDuLieu() {
		System.out.println( "Nhập tên công ty: ");
		this._ten_cong_ty = scan.nextLine();
		
		System.out.println( "Nhập mã số thuế: ");
		this._ma_so_thue = scan.nextLine();
		
		System.out.println( "Nhập doanh thu tháng: ");
		this._doanh_thu_thang = Float.parseFloat(scan.nextLine());
	}
	
	public void XuatDuLieu() {
		
	}
	
	public void ThemNhanSu( Scanner scan ) {		
		System.out.println( "Mời bạn chọn chức vụ: ");
		System.out.println("1. Nhân viên     2. Trưởng Phòng     3.Sếp");
		int chuc_vu = Integer.parseInt(scan.nextLine());
		NhanSu ns = null;
		switch (chuc_vu) {
		case 1:
			ns = new NhanVien();
			((NhanVien)ns).NhapDuLieu(this);
			break;
		case 2:
			ns = new TruongPhong(); 
			ns.NhapDuLieu();
			break;
			
		case 3:
			ns = new Sep(); 
			ns.NhapDuLieu();
			break;
		}		
		ns.TinhLuong();
		this._luong_thang_cua_cong_ty += ns.getLuongThang();
		this._list_ns.add(ns);
	}
	
	public void XoaNhanVienTheoMa() {
		Scanner scan = new Scanner(System.in);
		System.out.println( "Mời bạn nhập mã nhân viên cần xóa: ");
		int ma_can_xoa = Integer.parseInt(scan.nextLine());
		
		for( int i = 0 ; i < this._list_ns.size(); i++ ) {
			NhanSu ns = this._list_ns.get(i);
			if( ns.getMaSo() == ma_can_xoa ) {
				System.out.println( "Đã xóa nhân viên " + ma_can_xoa );
				if( ns instanceof TruongPhong ) {
					((TruongPhong)ns).XoaLienKetKhoiCacNhanVien();
				}
				this._luong_thang_cua_cong_ty -= ns.getLuongThang();
				this._list_ns.remove(i);
				break;
			}
		}
	}
	
	public void XuatThongTinToanBoCongTy() {
		System.out.println( "THÔNG TIN TOÀN BỘ NHÂN SỰ:");
		for( int i = 0 ; i < this._list_ns.size(); i++ ) {
			NhanSu nv = this._list_ns.get(i);
			nv.XuatDuLieu();
		}
	}
	
	public TruongPhong KiemTraTruongPhongTonTai( int ma_tp_can_kiem_tra ) {
		for( NhanSu ns : this._list_ns ) {
			if( ns instanceof TruongPhong && ma_tp_can_kiem_tra == ns.getMaSo() ) {
				return (TruongPhong)ns;
			}
		}
		return null;
	}
	
	public float TinhLoiNhuanCuaCongTy() {
		return this._doanh_thu_thang - this._luong_thang_cua_cong_ty;
	}
	
	public void TinhVaXuatThuNhapCuaCacGiamDoc() {
		float loi_nhuan = this.TinhLoiNhuanCuaCongTy();
		for( NhanSu ns : this._list_ns ) {
			if( ns instanceof Sep ) {	
				System.out.println( "Giám đốc " + ns.getHoTen() + 
						" có tổng thu nhập là: " + ((Sep)ns).TinhThuNhapThang(loi_nhuan));
			}
		}
	}
	
	public static void XuatThongTinToanBoCongTy2( CongTy cty ) {
		System.out.println( "THÔNG TIN TOÀN BỘ NHÂN SỰ:");
		for( int i = 0 ; i < cty._list_ns.size(); i++ ) {
			NhanSu nv = cty._list_ns.get(i);
			nv.XuatDuLieu();
		}
	}
	
	public static CongTy SoSanhSL_NhanSu_2_Congty( CongTy cty1, CongTy cty2 ) {
		if( cty1._list_ns.size() > cty2._list_ns.size() )
			return cty1;
		return cty2;
	}
}
