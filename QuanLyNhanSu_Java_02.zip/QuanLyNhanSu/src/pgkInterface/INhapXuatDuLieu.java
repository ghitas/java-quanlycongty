package pgkInterface;

import java.util.Scanner;

public interface INhapXuatDuLieu {
	public static final Scanner scan = new Scanner( System.in );
	
	public void NhapDuLieu();
	public void XuatDuLieu();
}
