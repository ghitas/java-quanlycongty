package pgkMain;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

import pgkNhanSu.NhanSu;
import pgkNhanSu.NhanVien;
import pgkNhanSu.Sep;
import pgkNhanSu.TruongPhong;
import pgkQuanLy.CongTy;

public class MAIN {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		CongTy cong_ty = new CongTy();
		cong_ty.NhapDuLieu(scan);	
		
		while( true ) {
			System.out.println("MENU");
			System.out.println("0. Thoát");
			System.out.println("1. Thêm 1 nhân sự mới");
			System.out.println("2. Xuất thông tin toàn bộ nhân sự");
			System.out.println("3. Xóa nhân viên theo mã");
			System.out.println( "4. Tính và xuất tổng thu nhập của các Giám Đốc");
			System.out.println("Mời bạn chọn: ");
			int lua_chon = Integer.parseInt(scan.nextLine());
			
			if( lua_chon == 0 )
				break;
			
			switch (lua_chon) {
			case 1:
				//Gọi chức năng thêm nhân sự
				cong_ty.ThemNhanSu(scan);
				break;
			case 2:
				//Gọi chức năng xuất thông tin toàn bộ cty
				cong_ty.XuatThongTinToanBoCongTy();
				break;
			case 3:
				//Gọi chức năng xuất lương toàn bộ cty
				cong_ty.XoaNhanVienTheoMa();
				break;
			case 4:
				cong_ty.TinhVaXuatThuNhapCuaCacGiamDoc();
				break;
			default:
				break;
			}
		}
		
		scan.close();
	}

	
	

}
