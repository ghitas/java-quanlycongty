package com.myclass.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myclass.entity.Product;

@WebServlet(name = "ProductServlet", urlPatterns = {
		"/product", "/product/add", "/product/edit", "/product/delete"
})
public class ProductServlet extends HttpServlet {

	List<Product> list = null;

	@Override
	public void init() throws ServletException {
		list = new ArrayList<Product>();
		list.add(new Product(1, "Samsung Galaxy", 20, 10000000));
		list.add(new Product(2, "Iphone 8", 50, 20000000));
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// Lấy ra url
		String action = req.getServletPath();
		
		// Lấy ra danh sách sản phẩm
		if(action.equals("/product")) {
			// Gửi danh sách về cho product.jsp
			req.setAttribute("action", "/product/add");
			req.setAttribute("products", list);
			req.getRequestDispatcher("/product.jsp").forward(req, resp);
		}
		// Lấy ra thông tin 1 một sản phẩm theo id
		else if(action.equals("/product/edit")) {
			req.setAttribute("action", "/product/edit");
			// Lấy tham số id từ url
			int id = Integer.parseInt(req.getParameter("id"));
			
			Product result = null;
			// Lặp danh sách => lấy ra sản phẩm có cùng id với id truyền vào
			for (Product product : list) {
				if(product.getId() == id) {
					result = product;
					break;
				}
			}
			// Trả về cho product.jsp
			req.setAttribute("product", result);
			req.setAttribute("products", list);
			req.getRequestDispatcher("/product.jsp").forward(req, resp);
		}
		else if(action.equals("/product/delete")) {
			// Lấy tham số id từ url
			int id = Integer.parseInt(req.getParameter("id"));
			for (Product product : list) {
				if(product.getId() == id) {
					list.remove(product);
					break;
				}
			}
			// Quay lại trang danh sách
			resp.sendRedirect(req.getContextPath() + "/product");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// Lấy ra url
		String action = req.getServletPath();
		
		// VALIDATE FORM
		boolean valid = true;
		valid = validateForm(req, resp, "id", "Vui lòng nhập Id!");
		if(valid) {
			valid = validateForm(req, resp, "name", "Vui lòng nhập tên sản phẩm!");
		}
		
		if(valid) {
			// Lấy thông tin form
			int id = Integer.parseInt(req.getParameter("id"));
			String name = req.getParameter("name");
			int quantity = Integer.parseInt(req.getParameter("quantity"));
			float price = Float.parseFloat(req.getParameter("price"));

			// THÊM MỚI
			if(action.equals("/product/add")) {
				// Thêm sản phẩm vào list
				Product product = new Product(id, name, quantity, price);
				list.add(product);
			}
			// CẬP NHẬT
			else {
				// Lặp danh sách => lấy ra sản phẩm có cùng id với id truyền vào
				for (Product product : list) {
					if(product.getId() == id) { // Nếu tìm thấy => cập nhật lại giá trị từng thuộc tính
						product.setName(name);
						product.setQuantity(quantity);
						product.setPrice(price);
					}
				}
			}
			
			// Quay lại trang danh sách
			resp.sendRedirect(req.getContextPath() + "/product");
		}
	}
	
	/*
	 * Mục đích: Hàm kiểm tra thông tin form
	 * Người tạo: Tiến Hoàng
	 * Ngày tạo: 14/07/2019
	 * */
	private boolean validateForm(HttpServletRequest req, HttpServletResponse resp, String param, String message) 
			throws ServletException, IOException {
		
		if (req.getParameter(param) == null || req.getParameter(param).isEmpty()) {

			req.setAttribute("message", message);
			req.setAttribute("products", list);
			req.getRequestDispatcher("/product.jsp").forward(req, resp);
			return false;
		}
		return true;
	}
}
