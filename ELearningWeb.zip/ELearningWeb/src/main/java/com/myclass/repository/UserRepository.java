package com.myclass.repository;

import java.util.List;

import com.myclass.entity.User;

public interface UserRepository {
	List<User> findAll();
	User findById(String id);
	void save(User User);
	void update(User User);
	void removeById(String id);
}
