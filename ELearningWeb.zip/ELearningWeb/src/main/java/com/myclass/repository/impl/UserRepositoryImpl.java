package com.myclass.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.myclass.entity.User;
import com.myclass.repository.UserRepository;

@Repository
public class UserRepositoryImpl implements UserRepository{

	private List<User> users = null;
	public UserRepositoryImpl() {
		users = new ArrayList<User>();
	}
	
	/**
	 * Mục đích: Phương thức lấy danh sách 
	 * Người tạo: Nguyễn Tiến Hoàng
	 * Ngày tạo: 25/08/2019
	 * Version: 01
	 */
	
	public List<User> findAll() {
		return users;
	}

	/**
	 * Mục đích: Phương thức thêm mới
	 * Người tạo: Nguyễn Tiến Hoàng
	 * Ngày tạo: 25/08/2019
	 * Version: 01
	 */
	
	public void save(User user) {
		users.add(user);
	}

	public User findById(String id) {
		for(User user : users) {
			if(user.getId().equals(id)) {
				return user;
			}
		}
		return null;
	}

	public void update(User user) {
		User model = findById(user.getId());
		if(model != null) {
			model.setEmail(user.getEmail());
			model.setFullname(user.getFullname());
			model.setPassword(user.getPassword());
			model.setAvatar(user.getAvatar());
			model.setAddress(user.getAddress());
			model.setFacebook(user.getFacebook());
			model.setPhone(user.getPhone());
			model.setRoleId(user.getRoleId());
		}
	}

	public void removeById(String id) {
		User model = findById(id);
		if(model != null) {
			users.remove(model);
		}
	}
}
