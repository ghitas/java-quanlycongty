/**
 * Mục đích: Lớp xử lý dữ liệu quyền người dùng
 * Người tạo: Nguyễn Tiến Hoàng
 * Ngày tạo: 25/08/2019
 * Version: 01
 */

package com.myclass.repository.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.myclass.entity.Role;
import com.myclass.repository.RoleRepository;

@Repository
public class RoleRepositoryImpl implements RoleRepository {

	@Autowired
	SessionFactory sessionFactory;

	/**
	 * Mục đích: Phương thức lấy danh sách quyền Người tạo: Nguyễn Tiến Hoàng Ngày
	 * tạo: 25/08/2019 Version: 01
	 */

	public List<Role> findAll() {
		Session session = sessionFactory.openSession();
		List<Role> roles = null;
		try {
			Query<Role> query = session.createQuery("FROM roles", Role.class);
			roles = query.getResultList();
		}
		catch (HibernateException e) {
			e.printStackTrace();
		}
		finally {
			session.close();
		}
		
		return roles;
	}

	/**
	 * Mục đích: Phương thức thêm mới Người tạo: Nguyễn Tiến Hoàng Ngày tạo:
	 * 25/08/2019 Version: 01
	 */

	public void save(Role role) {
		// KHởi tạo Session
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			// Khởi tạo Transaction
			transaction = session.beginTransaction();

			// Truy vấn dữ liệu
			session.saveOrUpdate(role);

			// Thành công => Cập nhật dữ liệu vào db
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			// Thất bại => rollback
			transaction.rollback();
		} finally {
			// Hủy session tránh mất mát dữ liệu
			session.close();
		}
	}

	public Role findById(String id) {
		// KHởi tạo Session
		Session session = sessionFactory.openSession();
		Role role = null;
		try {
			// Truy vấn dữ liệu
			role = session.find(Role.class, id);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// Hủy session tránh mất mát dữ liệu
			session.close();
		}

		return role;
	}

	public void removeById(String id) {
		// KHởi tạo Session
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			// Khởi tạo Transaction
			transaction = session.beginTransaction();

			// Truy vấn dữ liệu
			Role role = findById(id);
			session.remove(role);

			// Thành công => Cập nhật dữ liệu vào db
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			// Thất bại => rollback
			transaction.rollback();
		} finally {
			// Hủy session tránh mất mát dữ liệu
			session.close();
		}
	}
}
