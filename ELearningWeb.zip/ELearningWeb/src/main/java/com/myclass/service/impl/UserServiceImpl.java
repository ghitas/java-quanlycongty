package com.myclass.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myclass.entity.User;
import com.myclass.repository.UserRepository;
import com.myclass.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;

	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	public void add(User user) {
		// Tạo Random Id
		String id = UUID.randomUUID().toString();
		user.setId(id);
		userRepository.save(user);
	}

	public User findById(String id) {
		return userRepository.findById(id);
	}

	public void update(User user) {
		userRepository.update(user);
	}

	public void removeById(String id) {
		userRepository.removeById(id);
	}
}
