package com.myclass.service;

import java.util.List;

import com.myclass.entity.User;

public interface UserService {
	List<User> findAll();
	User findById(String id);
	void add(User user);
	void update(User user);
	void removeById(String id);
}
