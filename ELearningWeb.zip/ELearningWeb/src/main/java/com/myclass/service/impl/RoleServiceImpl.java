package com.myclass.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myclass.entity.Role;
import com.myclass.repository.RoleRepository;
import com.myclass.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleRepository roleRepository;

	public List<Role> findAll() {
		// TODO Auto-generated method stub
		return roleRepository.findAll();
	}

	public void add(Role role) {
		// Tạo Random Id
		String id = UUID.randomUUID().toString();
		role.setId(id);
		roleRepository.save(role);
	}

	public Role findById(String id) {
		return roleRepository.findById(id);
	}

	public void update(Role role) {
		roleRepository.save(role);
	}

	public void removeById(String id) {
		roleRepository.removeById(id);
	}

}
